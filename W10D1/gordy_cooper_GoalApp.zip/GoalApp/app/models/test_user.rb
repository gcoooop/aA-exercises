# == Schema Information
#
# Table name: test_users
#
#  id         :bigint(8)        not null, primary key
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class TestUser < ApplicationRecord
end
